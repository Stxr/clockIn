package com.stxr.clockin.ui;

import android.support.v4.app.Fragment;

/**
 * Created by stxr on 2018/4/19.
 */

class FragmentFactory {
    public static Fragment createById(int id) {
        Fragment fragment = null;
        switch (id) {
//            case
        }
        return fragment;
    }
}
